<?php
//Custom Layouts
$layouts = array(
		'footer_359' => array(
				'name' => 'Footer',
				'template' => '[vc_row css=\".vc_custom_1491476722748{padding-top: 4rem !important;padding-bottom: 4rem !important;}\"][vc_column icons_position=\"left\"][trx_sc_content size=\"1_1\" number_position=\"br\" title_style=\"default\"][vc_row_inner][vc_column_inner width=\"1/4\" column_align=\"center\" icons_position=\"left\"][vc_wp_custommenu title=\"About Us\" nav_menu=\"43\"][/vc_column_inner][vc_column_inner width=\"1/4\" column_align=\"center\" icons_position=\"left\"][vc_wp_custommenu title=\"Donate\" nav_menu=\"44\"][/vc_column_inner][vc_column_inner width=\"1/4\" column_align=\"center\" icons_position=\"left\"][vc_wp_posts title=\"Newsroom\" number=\"2\" show_date=\"1\"][/vc_column_inner][vc_column_inner width=\"1/4\" column_align=\"center\" icons_position=\"left\"][trx_widget_contacts columns=\"\" googlemap=\"\" socials=\"1\" title=\"Connect\" address=\"123, New Lenox, Chicago, IL 60606\" phone=\"123-456-7890\" email=\"info@yoursite.com\"][/trx_widget_contacts][/vc_column_inner][/vc_row_inner][/trx_sc_content][/vc_column][/vc_row][vc_row row_delimiter=\"\" row_fixed=\"\" hide_on_tablet=\"\" hide_on_mobile=\"\" hide_on_frontpage=\"\" css=\".vc_custom_1494503552353{padding-top: 1.65rem !important;padding-bottom: 1.65rem !important;background-color: #ffffff !important;}\" el_class=\"copyright_area\"][vc_column icons_position=\"left\"][trx_sc_content size=\"1_1\" number_position=\"br\" title_style=\"default\"][vc_row_inner content_placement=\"middle\"][vc_column_inner width=\"1/4\" column_align=\"left\" icons_position=\"left\"][trx_sc_layouts_logo css=\".vc_custom_1491465876075{background-color: #ffffff !important;}\"][/vc_column_inner][vc_column_inner width=\"3/4\" column_align=\"right\" icons_position=\"left\"][vc_column_text]

<a href=\"https://themeforest.net/user/ancorathemes/portfolio\" target=\"_blank\" rel=\"noopener\">AncoraThemes</a> &copy; {Y}. All rights reserved.

[/vc_column_text][/vc_column_inner][/vc_row_inner][/trx_sc_content][/vc_column][/vc_row]',
				'meta' => array(
						'trx_addons_options' => array(
								'layout_type' => 'footer'
								),
						'_wpb_shortcodes_custom_css' => '.vc_custom_1491476722748{padding-top: 4rem !important;padding-bottom: 4rem !important;}.vc_custom_1494503552353{padding-top: 1.65rem !important;padding-bottom: 1.65rem !important;background-color: #ffffff !important;}'
						)
				),
		'header_452' => array(
				'name' => 'Header 1',
				'template' => '[vc_row content_placement=\"middle\" row_type=\"normal\" row_delimiter=\"\" row_fixed=\"1\" hide_on_tablet=\"\" hide_on_mobile=\"\" hide_on_frontpage=\"\"][vc_column icons_position=\"left\"][trx_sc_content size=\"1_1\" number_position=\"br\" title_style=\"default\"][vc_row_inner equal_height=\"yes\" content_placement=\"middle\"][vc_column_inner width=\"1/4\" column_align=\"left\" icons_position=\"left\"][trx_sc_layouts_logo][/vc_column_inner][vc_column_inner width=\"3/4\" column_align=\"right\" icons_position=\"left\"][trx_sc_layouts_menu location=\"menu_main\" mobile_button=\"1\" mobile_menu=\"1\" hide_on_mobile=\"1\"][trx_sc_layouts_search style=\"fullscreen\" ajax=\"1\" hide_on_tablet=\"1\" hide_on_mobile=\"1\"][trx_sc_button type=\"gradient\" icon_position=\"left\" hide_on_tablet=\"1\" hide_on_mobile=\"1\" link=\"/projects/\" title=\"Get Involved\" css=\".vc_custom_1494237196387{margin-left: 1em !important;}\"][/vc_column_inner][/vc_row_inner][/trx_sc_content][/vc_column][/vc_row][vc_row scheme=\"dark\" row_delimiter=\"\" row_fixed=\"\" hide_on_tablet=\"\" hide_on_mobile=\"\" hide_on_frontpage=\"\" css=\".vc_custom_1504017395840{padding-top: 9.3em !important;padding-bottom: 10.4em !important;background-image: url(http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/04/bg_pages.jpg?id=869) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}\" el_class=\"title_breadrumbs_block\"][vc_column icons_position=\"left\"][trx_sc_content size=\"1_1\" number_position=\"br\" title_style=\"default\"][vc_row_inner][vc_column_inner icons_position=\"left\"][trx_sc_layouts_title title=\"1\" meta=\"\" breadcrumbs=\"1\"][/vc_column_inner][/vc_row_inner][/trx_sc_content][/vc_column][/vc_row]',
				'meta' => array(
						'trx_addons_options' => array(
								'layout_type' => 'header'
								),
						'_wpb_shortcodes_custom_css' => '.vc_custom_1504017395840{padding-top: 9.3em !important;padding-bottom: 10.4em !important;background-image: url(http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/04/bg_pages.jpg?id=869) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1494237196387{margin-left: 1em !important;}'
						)
				),
		'header_655' => array(
				'name' => 'Header 1 (without title)',
				'template' => '[vc_row content_placement=\"middle\" row_type=\"normal\" row_delimiter=\"\" row_fixed=\"1\" hide_on_tablet=\"\" hide_on_mobile=\"\" hide_on_frontpage=\"\"][vc_column icons_position=\"left\"][trx_sc_content size=\"1_1\" number_position=\"br\" title_style=\"default\"][vc_row_inner equal_height=\"yes\" content_placement=\"middle\"][vc_column_inner width=\"1/4\" column_align=\"left\" icons_position=\"left\"][trx_sc_layouts_logo][/vc_column_inner][vc_column_inner width=\"3/4\" column_align=\"right\" icons_position=\"left\"][trx_sc_layouts_menu location=\"menu_main\" mobile_button=\"1\" mobile_menu=\"1\" hide_on_mobile=\"1\"][trx_sc_layouts_search style=\"fullscreen\" ajax=\"1\" hide_on_tablet=\"1\" hide_on_mobile=\"1\"][trx_sc_button type=\"gradient\" icon_position=\"left\" hide_on_tablet=\"1\" hide_on_mobile=\"1\" link=\"/projects/\" title=\"Get Involved\" css=\".vc_custom_1494237109280{margin-left: 1em !important;}\"][/vc_column_inner][/vc_row_inner][/trx_sc_content][/vc_column][/vc_row]',
				'meta' => array(
						'trx_addons_options' => array(
								'layout_type' => 'header'
								),
						'_wpb_shortcodes_custom_css' => '.vc_custom_1494237109280{margin-left: 1em !important;}'
						)
				),
		'header_722' => array(
				'name' => 'Header Fullwide',
				'template' => '[vc_row content_placement=\"middle\" row_type=\"normal\" row_delimiter=\"\" row_fixed=\"1\" hide_on_tablet=\"\" hide_on_mobile=\"\" hide_on_frontpage=\"\"][vc_column icons_position=\"left\"][vc_row_inner equal_height=\"yes\" content_placement=\"middle\" css=\".vc_custom_1493973212306{padding-right: 3em !important;padding-left: 3em !important;}\"][vc_column_inner width=\"1/4\" column_align=\"left\" icons_position=\"left\"][trx_sc_layouts_logo logo=\"736\"][/vc_column_inner][vc_column_inner width=\"3/4\" column_align=\"right\" icons_position=\"left\"][trx_sc_layouts_menu location=\"menu_main\" mobile_button=\"1\" mobile_menu=\"1\" hide_on_mobile=\"1\"][trx_sc_layouts_search style=\"fullscreen\" ajax=\"1\" hide_on_tablet=\"1\" hide_on_mobile=\"1\"][trx_sc_button type=\"gradient\" icon_position=\"left\" hide_on_tablet=\"1\" hide_on_mobile=\"1\" link=\"/projects/\" title=\"Get Involved\" css=\".vc_custom_1494238314771{margin-left: 1em !important;}\"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]',
				'meta' => array(
						'trx_addons_options' => array(
								'layout_type' => 'header'
								),
						'_wpb_shortcodes_custom_css' => '.vc_custom_1493973212306{padding-right: 3em !important;padding-left: 3em !important;}.vc_custom_1494238314771{margin-left: 1em !important;}'
						)
				),
		'header_20' => array(
				'name' => 'Header Short /2 rows/',
				'template' => '<p>[vc_row row_type=\"narrow\" row_delimiter=\"\" row_fixed=\"\" hide_on_tablet=\"\" hide_on_mobile=\"\" hide_on_frontpage=\"\"][vc_column column_align=\"center\" icons_position=\"left\" column_type=\"center\"][trx_sc_content size=\"1_1\" number_position=\"br\" title_style=\"default\" width=\"1_1\" padding=\"none\" width2=\"1_1\"][vc_row_inner equal_height=\"yes\" content_placement=\"middle\"][vc_column_inner width=\"1/3\" column_align=\"left\" icons_position=\"left\"][vc_column_text]<span style=\"color: #9b9b93; text-transform: uppercase; font-family: Montserrat; font-size: 0.875rem; font-weight: 500;\">let’s make our planet greener!</span>[/vc_column_text][/vc_column_inner][vc_column_inner width=\"2/3\" column_align=\"right\" icons_position=\"left\"][trx_sc_layouts_iconed_text icon=\"icon-phone-1\" icon_type=\"fontawesome\" icon_fontawesome=\"icon-phone-2\" text2=\"0 (800) 123-456\" text1=\"call us\" link=\"tel:0 (800) 123-456\"][/vc_column_inner][/vc_row_inner][/trx_sc_content][/vc_column][/vc_row][vc_row row_type=\"normal\" row_delimiter=\"1\" row_fixed=\"1\" hide_on_tablet=\"\" hide_on_mobile=\"\" hide_on_frontpage=\"\"][vc_column icons_position=\"left\" column_type=\"center\"][trx_sc_content size=\"1_1\" number_position=\"br\" title_style=\"default\" width=\"1_1\" padding=\"none\" width2=\"1_1\"][vc_row_inner equal_height=\"yes\" content_placement=\"middle\"][vc_column_inner width=\"1/4\" column_align=\"left\" icons_position=\"left\"][trx_sc_layouts_logo][/vc_column_inner][vc_column_inner width=\"3/4\" column_align=\"right\" icons_position=\"left\"][trx_sc_layouts_menu location=\"none\" menu=\"main-menu\" animation_in=\"fadeInUpSmall\" animation_out=\"fadeOutDownSmall\" mobile_button=\"1\" mobile_menu=\"1\" hide_on_mobile=\"1\" burger=\"\" mobile=\"1\" stretch=\"\" mobile_hide=\"1\"][trx_sc_socials icons=\"%5B%7B%22icon%22%3A%22Array%22%7D%5D\" title_style=\"default\" hide_on_tablet=\"1\" hide_on_mobile=\"1\"][/vc_column_inner][/vc_row_inner][/trx_sc_content][/vc_column][/vc_row]</p>
',
				'meta' => array(
						'trx_addons_options' => array(
								'layout_type' => 'header'
								)
						)
				),
		'custom_303' => array(
				'name' => 'Our Mission',
				'template' => '[vc_row][vc_column icons_position=\"left\"][trx_sc_promo title_style=\"default\" title_align=\"center\" image_position=\"left\" size=\"normal\" full_height=\"\" text_float=\"center\" text_align=\"center\" text_paddings=\"1\" icon_type=\"fontawesome\" image=\"293\" css=\".vc_custom_1492673866902{background-color: #a1c643 !important;}\"][vc_column_text]
<h3 style=\"text-align: center; margin-bottom: 2rem;\"><span style=\"color: #ffffff;\"><em style=\"text-transform: capitalize;\">Our</em> Mission</span></h3>
<span style=\"background-color: white; color: #a1c643; width: 52px; height: 2px; display: block; overflow: hidden; margin: 0 auto 2.1rem;\">line</span>
<p style=\"text-align: center;\"><span style=\"color: #ffffff;\">Better ecology, clean water source</span>
<span style=\"color: #ffffff;\"> an animal living freely within its healthy</span>
<span style=\"color: #ffffff;\"> environment, always.</span></p>
[/vc_column_text][trx_sc_button type=\"white\" size=\"large\" align=\"center\" icon_position=\"left\" link=\"/how-we-work/\" title=\"more about us\" css=\".vc_custom_1492674233429{margin-top: 2.4rem !important;}\"][/trx_sc_promo][/vc_column][/vc_row]',
				'meta' => array(
						'trx_addons_options' => array(
								'layout_type' => 'custom'
								),
						'_wpb_shortcodes_custom_css' => '.vc_custom_1492673866902{background-color: #a1c643 !important;}.vc_custom_1492674233429{margin-top: 2.4rem !important;}'
						)
				),
		'custom_554' => array(
				'name' => 'Our Mission (white)',
				'template' => '[vc_row][vc_column icons_position=\"left\"][trx_sc_promo title_style=\"default\" title_align=\"center\" image_position=\"left\" size=\"normal\" full_height=\"\" text_float=\"center\" text_align=\"center\" text_paddings=\"1\" icon_type=\"fontawesome\" image=\"293\" css=\".vc_custom_1492694538590{background-color: #ffffff !important;}\"][vc_column_text]
<h3 style=\"text-align: center; margin-bottom: 2rem;\"><em style=\"text-transform: capitalize;\">Our</em> Mission</h3>
<span style=\"background-color: #a1c643; color: #a1c643; width: 52px; height: 2px; display: block; overflow: hidden; margin: 0 auto 2.1rem;\">line</span>
<p style=\"text-align: center;\">Better ecology, clean water source
an animal living freely within its healthy
environment, always.</p>
[/vc_column_text][trx_sc_button type=\"gradient\" size=\"large\" align=\"center\" icon_position=\"left\" link=\"/our-mission/\" title=\"more about us\" css=\".vc_custom_1492694912458{margin-top: 2.4rem !important;}\"][/trx_sc_promo][/vc_column][/vc_row]',
				'meta' => array(
						'trx_addons_options' => array(
								'layout_type' => 'custom'
								),
						'_wpb_shortcodes_custom_css' => '.vc_custom_1492694538590{background-color: #ffffff !important;}.vc_custom_1492694912458{margin-top: 2.4rem !important;}'
						)
				),
		'custom_320' => array(
				'name' => 'Partners',
				'template' => '[vc_row full_width=\"stretch_row\" css=\".vc_custom_1493895439912{padding-top: 5rem !important;padding-bottom: 5rem !important;background-color: #a1c643 !important;}\"][vc_column icons_position=\"left\"][trx_widget_slider engine=\"swiper\" slides_type=\"images\" noresize=\"1\" effect=\"slide\" direction=\"horizontal\" slides_per_view=\"8\" slides_space=\"78\" interval=\"5000\" controls=\"\" pagination=\"\" titles=\"center\" large=\"\" category=\"0\" posts=\"\" slides=\"%5B%7B%22image%22%3A%22328%22%7D%2C%7B%22image%22%3A%22327%22%7D%2C%7B%22image%22%3A%22326%22%7D%2C%7B%22image%22%3A%22325%22%7D%2C%7B%22image%22%3A%22324%22%7D%2C%7B%22image%22%3A%22323%22%7D%2C%7B%22image%22%3A%22322%22%7D%2C%7B%22image%22%3A%22321%22%7D%5D\"][/trx_widget_slider][/vc_column][/vc_row]',
				'meta' => array(
						'trx_addons_options' => array(
								'layout_type' => 'custom'
								),
						'_wpb_shortcodes_custom_css' => '.vc_custom_1493895439912{padding-top: 5rem !important;padding-bottom: 5rem !important;background-color: #a1c643 !important;}'
						)
				),
		'custom_318' => array(
				'name' => 'Photogallery',
				'template' => '[vc_row full_width=\"stretch_row\" css=\".vc_custom_1493895363569{padding-top: 7.45rem !important;padding-bottom: 7.8rem !important;background-image: url(http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/bg_gallery.jpg?id=316) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}\"][vc_column icons_position=\"left\"][trx_sc_title title_style=\"default\" title_align=\"center\" scheme=\"dark\" title=\"Our Gallery\" subtitle=\"photogallery\" css=\".vc_custom_1493894363855{margin-bottom: 4.3rem !important;}\"][ess_grid alias=\"photogallery\"][/vc_column][/vc_row]',
				'meta' => array(
						'trx_addons_options' => array(
								'layout_type' => 'custom'
								),
						'_wpb_shortcodes_custom_css' => '.vc_custom_1493895363569{padding-top: 7.45rem !important;padding-bottom: 7.8rem !important;background-image: url(http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/bg_gallery.jpg?id=316) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1493894363855{margin-bottom: 4.3rem !important;}'
						)
				),
		'custom_186' => array(
				'name' => 'Signup',
				'template' => '[vc_row full_width=\"stretch_row\" css=\".vc_custom_1491492610034{padding-top: 4.8rem !important;padding-bottom: 5rem !important;background-image: url(http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/bg_newsletter.jpg?id=182) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}\"][vc_column width=\"1/2\" icons_position=\"left\"][vc_column_text]
<h4 class=\"trx_addons_no_margin\"><span style=\"color: #ffffff;\"><em>Stay</em> Tuned with Our Updates</span></h4>
<span style=\"color: #ffffff; font-family: Montserrat; font-size: 0.875rem; font-weight: 500; text-transform: uppercase;\">signup for newsletter</span>[/vc_column_text][/vc_column][vc_column width=\"1/2\" icons_position=\"left\"][vc_column_text][mc4wp_form id=\"488\"][/vc_column_text][/vc_column][/vc_row]',
				'meta' => array(
						'trx_addons_options' => array(
								'layout_type' => 'custom'
								),
						'_wpb_shortcodes_custom_css' => '.vc_custom_1491492610034{padding-top: 4.8rem !important;padding-bottom: 5rem !important;background-image: url(http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/bg_newsletter.jpg?id=182) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}'
						)
				),
		'custom_300' => array(
				'name' => 'Testimonials',
				'template' => '[vc_row][vc_column width=\"1/6\" icons_position=\"left\"][/vc_column][vc_column width=\"2/3\" icons_position=\"left\"][trx_sc_testimonials type=\"simple\" orderby=\"none\" slider=\"1\" slider_pagination=\"bottom\" slider_pagination_thumbs=\"1\" title_style=\"default\" count=\"5\" columns=\"1\"][/vc_column][vc_column width=\"1/6\" icons_position=\"left\"][/vc_column][/vc_row]',
				'meta' => array(
						'trx_addons_options' => array(
								'layout_type' => 'custom'
								)
						)
				)
		);
?>